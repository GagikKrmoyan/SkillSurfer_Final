package com.example.diliproj;

import java.util.HashMap;
import java.util.Map;

public class Course {
    private String title;
    private String description;
    private String place;
    private String paidOrFree;
    private String imageUrl;

    public Course() {}

    public Course(String title, String description, String place, String paidOrFree) {
        this.title = title;
        this.description = description;
        this.place = place;
        this.paidOrFree = paidOrFree;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getPaidOrFree() {
        return paidOrFree;
    }

    public void setPaidOrFree(String paidOrFree) {
        this.paidOrFree = paidOrFree;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("title", title);
        result.put("description", description);
        result.put("place", place);
        result.put("paidOrFree", paidOrFree);
        result.put("imageUrl", imageUrl);
        return result;
    }
}
