package com.example.diliproj;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;

public class CourseInfo extends AppCompatActivity {

    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_info);


    Button   registerButton = findViewById(R.id.registerButton);

        registerButton.setOnClickListener(view -> showRegistrationDialog());

        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        String desc = intent.getStringExtra("desc");
        String place = intent.getStringExtra("place");
        String paidOrFree = intent.getStringExtra("paidOrFree");
        String imageUriString = intent.getStringExtra("imageUri");

        TextView titleTv = findViewById(R.id.title);
        TextView descTv = findViewById(R.id.desc);
        TextView placeTv = findViewById(R.id.place);
        TextView paidOrFreeTv = findViewById(R.id.paidOrFree);
        ImageView photoImageView = findViewById(R.id.photoImageView);

        titleTv.setText(title);
        descTv.setText(desc);
        placeTv.setText(place);
        paidOrFreeTv.setText(paidOrFree);

        if (imageUriString != null) {
            Uri imageUri = Uri.parse(imageUriString);
            try {
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                photoImageView.setImageBitmap(bitmap);
                inputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void showRegistrationDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.registration_dialog);

        EditText nameEditText = dialog.findViewById(R.id.nameEditText);
        EditText emailEditText = dialog.findViewById(R.id.emailEditText);
        EditText phoneEditText = dialog.findViewById(R.id.phoneEditText);
        Button submitButton = dialog.findViewById(R.id.submitButton);

        submitButton.setOnClickListener(view -> {
            String name = nameEditText.getText().toString().trim();
            String email = emailEditText.getText().toString().trim();
            String phone = phoneEditText.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Perform registration logic here
                String registrationDetails = "Name: " + name + "\n"
                        + "Email: " + email + "\n"
                        + "Phone: " + phone;

                Toast.makeText(this, "Successfully registered!\n\n" + registrationDetails, Toast.LENGTH_LONG).show();

                dialog.dismiss();
            }
        });

        dialog.show();
    }
}
