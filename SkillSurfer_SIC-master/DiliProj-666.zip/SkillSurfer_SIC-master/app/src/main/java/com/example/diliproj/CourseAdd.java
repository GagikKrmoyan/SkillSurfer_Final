package com.example.diliproj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CourseAdd extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText titleEditText;
    private EditText descEditText;
    private EditText placeEditText;
    private EditText paidOrFreeEditText;
    private Button addPhotoButton;
    private ImageView photoImageView;
    private Button addCourseButton;
    private Button exitButton;

    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_add);

        titleEditText = findViewById(R.id.title);
        descEditText = findViewById(R.id.desc);
        placeEditText = findViewById(R.id.place);
        paidOrFreeEditText = findViewById(R.id.paidOrFree);
        addPhotoButton = findViewById(R.id.addPhoto);
        photoImageView = findViewById(R.id.photoImageView);
        addCourseButton = findViewById(R.id.addC);

        addCourseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve input values
                String title = titleEditText.getText().toString();
                String desc = descEditText.getText().toString();
                String place = placeEditText.getText().toString();
                String paidOrFree = paidOrFreeEditText.getText().toString();


                if (title.isEmpty() || desc.isEmpty() || place.isEmpty() || paidOrFree.isEmpty()) {

                    Toast.makeText(CourseAdd.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    if (title.isEmpty()) {
                        titleEditText.setHintTextColor(getResources().getColor(R.color.purple_200 ));
                    }
                    if (desc.isEmpty()) {
                        descEditText.setHintTextColor(getResources().getColor(R.color.purple_200));
                    }
                    if (place.isEmpty()) {
                        placeEditText.setHintTextColor(getResources().getColor(R.color.purple_200));
                    }
                    if (paidOrFree.isEmpty()) {
                        paidOrFreeEditText.setHintTextColor(getResources().getColor(R.color.purple_200));
                    }
                    return;
                }

                Course crs = new Course(title, desc, place, paidOrFree);

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference coursesRef = database.getReference("Courses");

                String courseId = coursesRef.push().getKey();
                Map<String, Object> courseValues = crs.toMap();
                Map<String, Object> childUpdates = new HashMap<>();
                childUpdates.put(courseId, courseValues);
                coursesRef.updateChildren(childUpdates);

                if (selectedImageUri != null) {
                    try {
                        byte[] imageBytes = convertImageToByteArray(selectedImageUri);
                        if (imageBytes != null) {
                            DatabaseReference imageRef = coursesRef.child(courseId).child("image");
                            imageRef.setValue(imageBytes);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                Toast.makeText(CourseAdd.this, "Course added successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        addPhotoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageSelection();
            }
        });
    }

    private void openImageSelection() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    private byte[] convertImageToByteArray(Uri imageUri) throws IOException {
        Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        baos.close();
        return imageBytes;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            try {
                byte[] imageBytes = convertImageToByteArray(selectedImageUri);
                if (imageBytes != null) {
                    photoImageView.setImageBitmap(BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length));
                }
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(CourseAdd.this, "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }

    }
}